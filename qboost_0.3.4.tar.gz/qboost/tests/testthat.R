library(testthat)
library(qboost)

test_check("qboost")
